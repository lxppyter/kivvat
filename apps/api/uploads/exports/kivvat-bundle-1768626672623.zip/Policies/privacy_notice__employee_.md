# Privacy Notice (Employee)

# Privacy Notice

## Your Rights
Under GDPR/KVKK, you have the right to access your personal data...