# Password Policy

# Password Policy

## Requirements
- Minimum 12 characters
- Mixed case, numbers, symbols...