# Incident Management Procedure

# Incident Management

## Process
1. Identify
2. Contain
3. Eradicate
4. Recover...