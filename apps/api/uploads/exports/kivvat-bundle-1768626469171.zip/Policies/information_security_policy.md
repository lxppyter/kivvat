# Information Security Policy

# Information Security Policy

## Purpose
The purpose of this policy is to protect the information assets of {{companyName}}...