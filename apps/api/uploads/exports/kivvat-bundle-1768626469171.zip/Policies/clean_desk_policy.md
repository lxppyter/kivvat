# Clean Desk Policy

# Clean Desk Policy

## Overview
Sensitive information must be secured when workspace is unattended...